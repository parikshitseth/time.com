# How to run?
## Step 1:
```
npm install
```
## Step 2:
```
npm start
```

## Step 3:

open in the browser 

http://localhost:8080/getTimeStories